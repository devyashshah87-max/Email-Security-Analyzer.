
import pandas as pd
import joblib
from pathlib import Path

from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)

DATA = Path("data/1st data/2nd_data-spam-ham-email_results")
MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)

# Load ham and spam datasets
ham = pd.read_csv(DATA / "hamResults.csv", encoding="latin1")
spam = pd.read_csv(DATA / "spamResults.csv", encoding="latin1")

# Assign labels based on dataset source
ham_data = pd.DataFrame({
    "message": ham["message"],
    "label": 0
})

spam_data = pd.DataFrame({
    "message": spam["message"],
    "label": 1
})

# Combine datasets
df = pd.concat([ham_data, spam_data], ignore_index=True)

# Clean data
df["message"] = df["message"].fillna("").astype(str).str.strip()
df = df[df["message"] != ""]
df = df.drop_duplicates(subset=["message"])

X = df["message"]
y = df["label"]

print("Dataset size:", len(df))
print("Ham:", (y == 0).sum())
print("Spam:", (y == 1).sum())

# Split training and testing data
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# Build ML pipeline
model = Pipeline([
    ("tfidf", TfidfVectorizer(
        stop_words="english",
        max_features=10000,
        ngram_range=(1, 2)
    )),
    ("classifier", LogisticRegression(
        max_iter=1000,
        class_weight="balanced"
    ))
])

# Train
print("\nTraining model...")
model.fit(X_train, y_train)

# Evaluate
predictions = model.predict(X_test)

print("\nAccuracy:", accuracy_score(y_test, predictions))
print("\nClassification Report:")
print(classification_report(
    y_test,
    predictions,
    target_names=["Ham", "Spam"]
))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, predictions))

# Save model
joblib.dump(model, MODEL_DIR / "email_classifier.pkl")

print("\nModel saved successfully!")
