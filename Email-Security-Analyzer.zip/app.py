
import streamlit as st
import pandas as pd
import joblib
import re
from datetime import datetime
from pathlib import Path
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------

st.set_page_config(
    page_title="Email Security Analyzer",
    page_icon="🔐",
    layout="wide",
    initial_sidebar_state="expanded"
)

MODEL_PATH = Path("models/email_classifier.pkl")

# --------------------------------------------------
# LOAD MODEL
# --------------------------------------------------

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

try:
    model = load_model()
    analyzer = SentimentIntensityAnalyzer()
except Exception as error:
    st.error(f"Unable to load model: {error}")
    st.stop()

# --------------------------------------------------
# SESSION STATE
# --------------------------------------------------

if "history" not in st.session_state:
    st.session_state.history = []

if "last_result" not in st.session_state:
    st.session_state.last_result = None

# --------------------------------------------------
# STYLING
# --------------------------------------------------

st.markdown("""
<style>
.main {
    background-color: #0e1117;
}
.block-container {
    padding-top: 2rem;
    padding-bottom: 3rem;
}
[data-testid="stMetric"] {
    background-color: #171c27;
    border: 1px solid #293246;
    padding: 18px;
    border-radius: 12px;
}
div[data-testid="stSidebar"] {
    background-color: #121722;
}
h1, h2, h3 {
    letter-spacing: -0.5px;
}
.small-muted {
    color: #9ca3af;
}
</style>
""", unsafe_allow_html=True)

# --------------------------------------------------
# ANALYSIS FUNCTIONS
# --------------------------------------------------

SUSPICIOUS_PHRASES = [
    "urgent",
    "verify your account",
    "click here",
    "password",
    "bank account",
    "limited time",
    "claim your prize",
    "account suspended",
    "confirm your identity",
    "immediate action",
    "update your payment",
    "security alert",
    "unusual activity",
    "wire transfer",
    "gift card"
]

def analyze_email(email):

    prediction = int(model.predict([email])[0])

    probabilities = model.predict_proba([email])[0]

    classes = list(model.classes_)
    confidence = float(
        probabilities[classes.index(prediction)] * 100
    )

    sentiment = analyzer.polarity_scores(email)

    compound = sentiment["compound"]

    if compound >= 0.05:
        mood = "Positive"
    elif compound <= -0.05:
        mood = "Negative"
    else:
        mood = "Neutral"

    urls = re.findall(
        r"https?://[^\s<>\"']+|www\.[^\s<>\"']+",
        email,
        flags=re.IGNORECASE
    )

    phrases = [
        phrase for phrase in SUSPICIOUS_PHRASES
        if phrase in email.lower()
    ]

    return {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "email": email,
        "classification": "SPAM" if prediction == 1 else "HAM",
        "prediction": prediction,
        "confidence": round(confidence, 2),
        "sentiment": mood,
        "positive": round(sentiment["pos"], 3),
        "negative": round(sentiment["neg"], 3),
        "neutral": round(sentiment["neu"], 3),
        "compound": round(compound, 3),
        "url_count": len(urls),
        "urls": ", ".join(urls),
        "suspicious_count": len(phrases),
        "suspicious_phrases": ", ".join(phrases)
    }


def save_result(result):
    st.session_state.history.insert(0, result)
    st.session_state.last_result = result


def show_result(result):

    st.divider()
    st.subheader("Analysis Results")

    c1, c2, c3 = st.columns(3)

    with c1:
        st.metric(
            "Email Classification",
            result["classification"]
        )

    with c2:
        st.metric(
            "Prediction Confidence",
            f'{result["confidence"]}%'
        )

    with c3:
        st.metric(
            "Sentiment",
            result["sentiment"]
        )

    if result["classification"] == "SPAM":
        st.error("The model classified this email as SPAM.")
    else:
        st.success("The model classified this email as HAM.")

    st.subheader("Sentiment Analysis")

    sentiment_df = pd.DataFrame({
        "Sentiment": ["Positive", "Negative", "Neutral"],
        "Score": [
            result["positive"],
            result["negative"],
            result["neutral"]
        ]
    })

    st.bar_chart(
        sentiment_df.set_index("Sentiment")
    )

    c1, c2, c3 = st.columns(3)

    c1.metric("Positive", result["positive"])
    c2.metric("Negative", result["negative"])
    c3.metric("Neutral", result["neutral"])

    st.metric("Compound Sentiment", result["compound"])

    st.subheader("Email Risk Indicators")

    c1, c2 = st.columns(2)

    c1.metric("URLs Detected", result["url_count"])
    c2.metric(
        "Suspicious Phrases",
        result["suspicious_count"]
    )

    if result["suspicious_phrases"]:
        st.warning(
            "Detected phrases: " +
            result["suspicious_phrases"]
        )
    else:
        st.info("No listed suspicious phrases detected.")

    if result["urls"]:
        st.write("**Detected URLs:**")
        st.code(result["urls"])

    st.caption(
        "Spam classification is not equivalent to verified phishing "
        "detection. Sentiment and keyword indicators are supplementary "
        "signals and do not guarantee email safety."
    )


# --------------------------------------------------
# SIDEBAR NAVIGATION
# --------------------------------------------------

st.sidebar.title("🔐 Email Security")
st.sidebar.caption("Machine Learning & Sentiment Analysis")
st.sidebar.divider()

page = st.sidebar.radio(
    "Navigation",
    [
        "Dashboard",
        "Email Scanner",
        "Bulk Analysis",
        "Analytics",
        "Analysis History",
        "About Project"
    ]
)

st.sidebar.divider()

st.sidebar.markdown("### Model Information")
st.sidebar.success("Model loaded successfully")
st.sidebar.write("Algorithm: Logistic Regression")
st.sidebar.write("Feature Extraction: TF-IDF")
st.sidebar.write("Sentiment: VADER")

st.sidebar.caption("Developed using Python and Streamlit")

# --------------------------------------------------
# DASHBOARD
# --------------------------------------------------

if page == "Dashboard":

    st.title("Email Security Dashboard")

    st.markdown(
        "Monitor email classification, sentiment and analysis activity."
    )

    history = st.session_state.history

    total = len(history)
    spam = sum(
        x["classification"] == "SPAM" for x in history
    )
    ham = sum(
        x["classification"] == "HAM" for x in history
    )

    avg_confidence = (
        sum(x["confidence"] for x in history) / total
        if total else 0
    )

    c1, c2, c3, c4 = st.columns(4)

    c1.metric("Emails Analysed", total)
    c2.metric("Spam Detected", spam)
    c3.metric("Ham Detected", ham)
    c4.metric("Average Confidence", f"{avg_confidence:.1f}%")

    st.divider()

    left, right = st.columns(2)

    with left:
        st.subheader("Classification Distribution")

        if total:
            chart = pd.DataFrame({
                "Category": ["Spam", "Ham"],
                "Emails": [spam, ham]
            }).set_index("Category")

            st.bar_chart(chart)
        else:
            st.info("Analyse an email to generate dashboard statistics.")

    with right:
        st.subheader("Recent Activity")

        if history:
            recent = pd.DataFrame(history[:5])

            st.dataframe(
                recent[
                    ["timestamp", "classification", "confidence", "sentiment"]
                ],
                use_container_width=True,
                hide_index=True
            )
        else:
            st.info("No analysis history available yet.")

    st.divider()

    st.subheader("Quick Start")

    st.write(
        "Navigate to Email Scanner to classify an email, "
        "or Bulk Analysis to process a CSV file."
    )


# --------------------------------------------------
# EMAIL SCANNER
# --------------------------------------------------

elif page == "Email Scanner":

    st.title("Email Scanner")
    st.write("Enter email content for machine learning analysis.")

    with st.form("email_form"):

        subject = st.text_input(
            "Email Subject",
            placeholder="Enter email subject..."
        )

        email = st.text_area(
            "Email Content",
            height=230,
            placeholder="Paste the complete email content here..."
        )

        submitted = st.form_submit_button(
            "Analyse Email",
            type="primary",
            use_container_width=True
        )

    if submitted:

        full_email = f"Subject: {subject}\n\n{email}".strip()

        if not email.strip():
            st.warning("Please enter email content.")
        else:
            with st.spinner("Analysing email..."):
                result = analyze_email(full_email)
                save_result(result)

            st.success("Email analysis completed!")

    if st.session_state.last_result:
        show_result(st.session_state.last_result)


# --------------------------------------------------
# BULK ANALYSIS
# --------------------------------------------------

elif page == "Bulk Analysis":

    st.title("Bulk Email Analysis")

    st.write(
        "Upload a CSV file containing emails to analyse multiple "
        "messages together."
    )

    uploaded_file = st.file_uploader(
        "Upload CSV",
        type=["csv"]
    )

    if uploaded_file:

        try:
            try:
                data = pd.read_csv(uploaded_file)
            except UnicodeDecodeError:
                uploaded_file.seek(0)
                data = pd.read_csv(
                    uploaded_file,
                    encoding="latin1"
                )

            st.write("Dataset Preview")
            st.dataframe(
                data.head(),
                use_container_width=True
            )

            if len(data.columns) == 0:
                st.error("The uploaded CSV has no columns.")
            else:
                selected_column = st.selectbox(
                    "Select the column containing email text",
                    data.columns
                )

                if st.button(
                    "Analyse All Emails",
                    type="primary"
                ):

                    texts = (
                        data[selected_column]
                        .dropna()
                        .astype(str)
                    )

                    if texts.empty:
                        st.warning("No email text found.")
                    else:
                        results = []

                        progress = st.progress(0)

                        for i, text in enumerate(texts):

                            result = analyze_email(text)
                            results.append(result)

                            progress.progress(
                                (i + 1) / len(texts)
                            )

                        st.session_state.history = (
                            results + st.session_state.history
                        )

                        st.success(
                            f"Successfully analysed {len(results)} emails."
                        )

                        results_df = pd.DataFrame(results)

                        st.dataframe(
                            results_df[
                                [
                                    "classification",
                                    "confidence",
                                    "sentiment",
                                    "url_count"
                                ]
                            ],
                            use_container_width=True
                        )

                        st.download_button(
                            "Download Bulk Results",
                            results_df.to_csv(index=False),
                            file_name="email_analysis_results.csv",
                            mime="text/csv"
                        )

        except Exception as error:
            st.error(f"Unable to process CSV: {error}")


# --------------------------------------------------
# ANALYTICS
# --------------------------------------------------

elif page == "Analytics":

    st.title("Email Analytics")

    history = st.session_state.history

    if not history:

        st.info(
            "No analytics available. Analyse some emails first."
        )

    else:

        df = pd.DataFrame(history)

        st.subheader("Classification Statistics")

        counts = df["classification"].value_counts()

        st.bar_chart(counts)

        st.subheader("Sentiment Distribution")

        sentiment_counts = df["sentiment"].value_counts()

        st.bar_chart(sentiment_counts)

        st.subheader("Prediction Confidence")

        st.line_chart(
            df["confidence"].reset_index(drop=True)
        )

        st.subheader("Detailed Statistics")

        st.dataframe(
            df[
                [
                    "classification",
                    "confidence",
                    "sentiment",
                    "positive",
                    "negative",
                    "neutral",
                    "url_count",
                    "suspicious_count"
                ]
            ].describe(),
            use_container_width=True
        )


# --------------------------------------------------
# ANALYSIS HISTORY
# --------------------------------------------------

elif page == "Analysis History":

    st.title("Analysis History")

    history = st.session_state.history

    if history:

        df = pd.DataFrame(history)

        st.write(f"Total records: {len(df)}")

        st.dataframe(
            df[
                [
                    "timestamp",
                    "classification",
                    "confidence",
                    "sentiment",
                    "url_count",
                    "suspicious_count"
                ]
            ],
            use_container_width=True,
            hide_index=True
        )

        st.download_button(
            "Download Complete History",
            df.to_csv(index=False),
            file_name="email_analysis_history.csv",
            mime="text/csv"
        )

        if st.button("Clear Analysis History"):

            st.session_state.history = []
            st.session_state.last_result = None

            st.rerun()

    else:

        st.info("No emails have been analysed in this session.")


# --------------------------------------------------
# ABOUT PROJECT
# --------------------------------------------------

elif page == "About Project":

    st.title("About the Project")

    st.subheader(
        "Phishing Email Analysis Using Machine Learning "
        "and Sentiment Analysis"
    )

    st.write("""
    This project demonstrates a machine learning-based email
    classification system combined with natural language processing.

    The system uses TF-IDF for text feature extraction and
    Logistic Regression for spam-versus-ham classification.

    VADER sentiment analysis identifies positive, negative and
    neutral emotional patterns in email content.

    Additional heuristic indicators identify suspicious phrases
    and URLs for supplementary inspection.
    """)

    st.subheader("Technologies Used")

    technologies = pd.DataFrame({
        "Technology": [
            "Python",
            "Pandas",
            "Scikit-learn",
            "TF-IDF",
            "Logistic Regression",
            "VADER",
            "Streamlit"
        ],
        "Purpose": [
            "Programming language",
            "Data processing",
            "Machine learning",
            "Text feature extraction",
            "Email classification",
            "Sentiment analysis",
            "Web application"
        ]
    })

    st.dataframe(
        technologies,
        use_container_width=True,
        hide_index=True
    )

    st.subheader("Model Evaluation")

    st.write("""
    The trained model achieved approximately 98.16% accuracy
    on a held-out test set of 1,032 emails from the spam and
    ham dataset.

    This is spam-versus-ham evaluation, not a verified
    phishing detection benchmark.
    """)

    st.info(
        "This application is an academic prototype. "
        "It should not be used as the sole basis for security decisions."
    )

# --------------------------------------------------
# FOOTER
# --------------------------------------------------

st.divider()

st.caption(
    "Email Security Analyzer | Machine Learning + NLP | "
    "Academic Project"
)
